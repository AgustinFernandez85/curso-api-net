﻿using System.ComponentModel.DataAnnotations;

namespace myFirstBackend.Models.DataModels
{
    public class Curso : BaseEntity
    {
        //en el enunciado no se muestra cuanto es el lengh
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [StringLength(280)]
        public string ShortDescription { get; set; } = string.Empty;

        public string LongDescription { get; set; } = string.Empty;

        public string TargetAudiences { get; set; } = string.Empty;

        public string Goals { get; set; } = string.Empty;

        public string Requirements { get; set; } = string.Empty;

        public Levels Level { get; set; }
    }

    public enum Levels
    {
        Basic,
        Intermediate,
        Advanced
    }
}
